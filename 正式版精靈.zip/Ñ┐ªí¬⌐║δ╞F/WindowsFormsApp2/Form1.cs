﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int [,]maze=new int[31, 28] {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1},
        {1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1},
        {1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1},
        {1,0,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,0,1,1,1,1,1,2,1,1,2,1,1,1,1,1,0,1,1,1,1,1,1},
        {1,1,1,1,1,1,0,1,1,1,1,1,2,1,1,2,1,1,1,1,1,0,1,1,1,1,1,1},
        {1,1,1,1,1,1,0,1,1,2,2,2,2,2,2,2,2,2,2,1,1,0,1,1,1,1,1,1},
        {1,1,1,1,1,1,0,1,1,2,1,1,1,1,1,1,1,1,2,1,1,0,1,1,1,1,1,1},
        {1,1,1,1,1,1,0,1,1,2,1,2,2,2,2,2,2,1,2,1,1,0,1,1,1,1,1,1},
        {4,0,0,0,0,0,0,2,2,2,1,2,2,2,2,2,2,1,2,2,2,0,0,0,0,0,0,3},
        {1,1,1,1,1,1,0,1,1,2,1,2,2,2,2,2,2,1,2,1,1,0,1,1,1,1,1,1},
        {1,1,1,1,1,1,0,1,1,2,1,1,1,1,1,1,1,1,2,1,1,0,1,1,1,1,1,1},
        {1,1,1,1,1,1,0,1,1,2,2,2,2,2,2,2,2,2,2,1,1,0,1,1,1,1,1,1},
        {1,1,1,1,1,1,0,1,1,2,1,1,1,1,1,1,1,1,2,1,1,0,1,1,1,1,1,1},
        {1,1,1,1,1,1,0,1,1,2,1,1,1,1,1,1,1,1,2,1,1,0,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1},
        {1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1},
        {1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1},
        {1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1},
        {1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1},
        {1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1},
        {1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        };

        int dx = 20, dy = 20;
        Bitmap bmp;
        Graphics g;
        Image street, wall,bean,streetB,Blinky,Pinky;
        int px, py,BlinkyX,BlinkyY,PinkyX,PinkyY;
        int direct = 22,new_direct = 22;
        int changeP = 2;
        int needchange1 = 0, needchange2 = 0, needchange3 = 0, needchange4 = 0;
        int start = 1, Out = 1, BeanCount = 256, SomeTimeS = 0,WinCount=0,HighScore=0;

        private void Wintimer_Tick(object sender, EventArgs e)
        {
            WinCount++;
            if (WinCount == 5)
            {
                button1.Visible = true;
                button1.Enabled = true;
                Wintimer.Enabled = false;
            }
        }

        int Pneedchange11 = 0, Pneedchange12 = 0, Pneedchange13 = 0, Pneedchange14 = 0;
        int BDecision = 0, PDecision = 0;
        int Point = 0, Life = 3, ResetCount = 0;

        private void SomeTime_Tick(object sender, EventArgs e)
        {
            SomeTimeS++;
            if(SomeTimeS==2)
            {
                for (int y = 0; y < 31; y++)
                {
                    for (int x = 0; x < 28; x++)
                    {
                        if (maze[y, x] == 5)
                        {
                            g.DrawImage(bean, x * dx, y * dy);
                            maze[y, x] = 0;
                        }
                    }
                }
                pictureBox1.Image = bmp;
                pictureBox1.Controls.Add(pictureBox2);
                pictureBox1.Controls.Add(pictureBox3);
                pictureBox1.Controls.Add(pictureBox4);
                pictureBox2.BackColor = Color.Transparent;
                pictureBox3.BackColor = Color.Transparent;
                pictureBox4.BackColor = Color.Transparent;
                pictureBox10.BackColor = Color.Transparent;

                pictureBox2.Image = Image.FromFile("PacMan42.png");
                pictureBox3.Image = Blinky;
                pictureBox4.Image = Pinky;
                px = 13; py = 23; BlinkyX = 13; BlinkyY = 11; PinkyX = 13; PinkyY = 14;
                pictureBox2.Left = px * dx;
                pictureBox2.Top = py * dy;
                pictureBox3.Left = BlinkyX * dx;
                pictureBox3.Top = BlinkyY * dy;
                pictureBox4.Left = PinkyX * dx;
                pictureBox4.Top = PinkyY * dy;

                pictureBox1.Visible = true;
                pictureBox2.Visible = true;
                pictureBox3.Visible = true;
                pictureBox4.Visible = true;
                pictureBox5.Visible = true;
                pictureBox6.Visible = true;
                pictureBox7.Visible = true;
                pictureBox8.Visible = true;
                pictureBox10.Visible = true;
                pictureBox11.Visible = false;
                pictureBox12.Visible = false;
                pictureBox13.Visible = false;

                Life = 3;

                label1.Visible = true;
                label2.Visible = true;
                Starter.Enabled = true;
                button3.Enabled = false;
                button1.Enabled = false;
                axWindowsMediaPlayer1.Ctlcontrols.play();

                SomeTimeS = 0;
                SomeTime.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            BeanCount = 256;
            Point = 0;
            timer3.Interval = 180;
            timer4.Interval = 180;
            label1.Text = 00.ToString();
            SomeTime.Enabled = true;
        }

        private void Reset_Tick(object sender, EventArgs e)
        {
            ResetCount++;
            if(ResetCount==5)
            {
                pictureBox9.Visible = false;
                button1.Visible = true;
                button1.Enabled = true;
                ResetCount = 0;
                Reset.Enabled = false;
            }
        }

        private void Starter_Tick(object sender, EventArgs e)
        {
            start++;
            if (start == 2)
                pictureBox10.Visible = true;
            if(start==6)
            {
                pictureBox10.Visible = false;
                start = 1;
                timer1.Enabled = true;
                timer2.Enabled = true;
                timer3.Enabled = true;
                PinkyOut.Enabled = true;
                Starter.Enabled = false;
            }
        }

        private void PinkyOut_Tick(object sender, EventArgs e)
        {
            Out++;
            if(Out==2||Out==3||Out==4)
            {
                PinkyY--;
                pictureBox4.Left = PinkyX * dx;
                pictureBox4.Top = PinkyY * dy;
            }
            if (Out == 5)
            {
                timer4.Enabled = true;
                Out = 1;
                PinkyOut.Enabled = false;
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            if (PDecision == 0)
            {
                if (direct == 22)
                {
                    if (PinkyX == px + 2)
                    {
                        if (PinkyY > py)
                        {
                            if (maze[PinkyY - 1, PinkyX] != 1)
                                PinkyY--;
                            else
                                PDecision = 1;
                        }
                        if (PinkyY < py)
                        {
                            if (maze[PinkyY + 1, PinkyX] != 1)
                                PinkyY++;
                            else
                                PDecision = 3;
                        }
                    }
                    else
                    {
                        if (PinkyX > px + 2)
                        {
                            if (PinkyY > py)
                            {
                                switch (Pneedchange11)
                                {
                                    case 0:
                                        {
                                            if (maze[PinkyY, PinkyX - 1] == 1)
                                            {
                                                if (maze[PinkyY - 1, PinkyX] == 1)
                                                    Pneedchange11 = 1;
                                                else
                                                    PinkyY--;
                                            }
                                            else
                                                PinkyX--;
                                            break;
                                        }
                                    case 1:
                                        {
                                            if (maze[PinkyY, PinkyX - 1] == 1)
                                                PinkyY++;
                                            else
                                            {
                                                PinkyX--;
                                                Pneedchange11 = 0;
                                            }
                                        }
                                        break;
                                }
                            }
                            if (PinkyY < py)
                            {
                                switch (Pneedchange12)
                                {
                                    case 0:
                                        {
                                            if (maze[PinkyY, PinkyX - 1] == 1)
                                            {
                                                if (maze[PinkyY + 1, PinkyX] == 1)
                                                    Pneedchange12 = 1;
                                                else
                                                    PinkyY++;
                                            }
                                            else
                                                PinkyX--;
                                            break;
                                        }
                                    case 1:
                                        {
                                            if (maze[PinkyY, PinkyX - 1] == 1)
                                                PinkyY--;
                                            else
                                            {
                                                PinkyX--;
                                                Pneedchange12 = 0;
                                            }
                                            break;
                                        }
                                }
                            }
                        }
                        if (PinkyX < px + 2)
                        {
                            if (PinkyY > py)
                            {
                                switch (Pneedchange13)
                                {
                                    case 0:
                                        {
                                            if (maze[PinkyY - 1, PinkyX] == 1)
                                            {
                                                if (maze[PinkyY, PinkyX + 1] == 1)
                                                    Pneedchange13 = 1;
                                                else
                                                    PinkyX++;
                                            }
                                            else
                                                PinkyY--;
                                            break;
                                        }
                                    case 1:
                                        {
                                            if (maze[PinkyY - 1, PinkyX] == 1)
                                                PinkyX--;
                                            else
                                            {
                                                PinkyY--;
                                                Pneedchange13 = 0;
                                            }
                                            break;
                                        }
                                }
                            }
                            if (PinkyY < py)
                            {
                                switch (Pneedchange14)
                                {
                                    case 0:
                                        {
                                            if (maze[PinkyY, PinkyX + 1] == 1)
                                            {
                                                if (maze[PinkyY + 1, PinkyX] == 1)
                                                    Pneedchange14 = 1;
                                                else
                                                    PinkyY++;
                                            }
                                            else
                                                PinkyX++;
                                            break;
                                        }
                                    case 1:
                                        {
                                            if (maze[PinkyY + 1, PinkyX] == 1)
                                                PinkyX--;
                                            else
                                            {
                                                PinkyY++;
                                                Pneedchange14 = 0;
                                            }
                                            break;
                                        }
                                }
                            }
                        }
                        if (PinkyY == py)
                        {
                            if (PinkyX > px + 2)
                            {
                                if (maze[PinkyY, PinkyX - 1] != 1)
                                    PinkyX--;
                                else
                                    PDecision = 4;
                            }
                            if (PinkyX < px + 2)
                            {
                                if (maze[PinkyY, PinkyX + 1] != 1)
                                    PinkyX++;
                                else
                                    PDecision = 2;
                            }
                        }
                    }
                }
                else
                {
                    if (direct == 12)
                    {
                        if (PinkyX == px)
                        {
                            if (PinkyY > py - 2)
                            {
                                if (maze[PinkyY - 1, PinkyX] != 1)
                                    PinkyY--;
                                else
                                    PDecision = 1;
                            }
                            if (PinkyY < py - 2)
                            {
                                if (maze[PinkyY + 1, PinkyX] != 1)
                                    PinkyY++;
                                else
                                    PDecision = 3;
                            }
                        }
                        else
                        {
                            if (PinkyX > px)
                            {
                                if (PinkyY > py - 2)
                                {
                                    switch (Pneedchange11)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                {
                                                    if (maze[PinkyY - 1, PinkyX] == 1)
                                                        Pneedchange11 = 1;
                                                    else
                                                        PinkyY--;
                                                }
                                                else
                                                    PinkyX--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                    PinkyY++;
                                                else
                                                {
                                                    PinkyX--;
                                                    Pneedchange11 = 0;
                                                }
                                            }
                                            break;
                                    }
                                }
                                if (PinkyY < py - 2)
                                {
                                    switch (Pneedchange12)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                {
                                                    if (maze[PinkyY + 1, PinkyX] == 1)
                                                        Pneedchange12 = 1;
                                                    else
                                                        PinkyY++;
                                                }
                                                else
                                                    PinkyX--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                    PinkyY--;
                                                else
                                                {
                                                    PinkyX--;
                                                    Pneedchange12 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                            }
                            if (PinkyX < px)
                            {
                                if (PinkyY > py - 2)
                                {
                                    switch (Pneedchange13)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY - 1, PinkyX] == 1)
                                                {
                                                    if (maze[PinkyY, PinkyX + 1] == 1)
                                                        Pneedchange13 = 1;
                                                    else
                                                        PinkyX++;
                                                }
                                                else
                                                    PinkyY--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY - 1, PinkyX] == 1)
                                                    PinkyX--;
                                                else
                                                {
                                                    PinkyY--;
                                                    Pneedchange13 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                                if (PinkyY < py - 2)
                                {
                                    switch (Pneedchange14)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX + 1] == 1)
                                                {
                                                    if (maze[PinkyY + 1, PinkyX] == 1)
                                                        Pneedchange14 = 1;
                                                    else
                                                        PinkyY++;
                                                }
                                                else
                                                    PinkyX++;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY + 1, PinkyX] == 1)
                                                    PinkyX--;
                                                else
                                                {
                                                    PinkyY++;
                                                    Pneedchange14 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                            }
                            if (PinkyY == py - 2)
                            {
                                if (PinkyX > px + 2)
                                {
                                    if (maze[PinkyY, PinkyX - 1] != 1)
                                        PinkyX--;
                                    else
                                        PDecision = 4;
                                }
                                if (PinkyX < px + 2)
                                {
                                    if (maze[PinkyY, PinkyX + 1] != 1)
                                        PinkyX++;
                                    else
                                        PDecision = 2;
                                }
                            }
                        }
                    }
                    if (direct == 32)
                    {
                        if (PinkyX == px)
                        {
                            if (PinkyY > py + 2)
                            {
                                if (maze[PinkyY - 1, PinkyX] != 1)
                                    PinkyY--;
                                else
                                    PDecision = 1;
                            }
                            if (PinkyY < py + 2)
                            {
                                if (maze[PinkyY + 1, PinkyX] != 1)
                                    PinkyY++;
                                else
                                    PDecision = 3;
                            }
                        }
                        else
                        {
                            if (PinkyX > px)
                            {
                                if (PinkyY > py + 2)
                                {
                                    switch (Pneedchange11)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                {
                                                    if (maze[PinkyY - 1, PinkyX] == 1)
                                                        Pneedchange11 = 1;
                                                    else
                                                        PinkyY--;
                                                }
                                                else
                                                    PinkyX--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                    PinkyY++;
                                                else
                                                {
                                                    PinkyX--;
                                                    Pneedchange11 = 0;
                                                }
                                            }
                                            break;
                                    }
                                }
                                if (PinkyY < py + 2)
                                {
                                    switch (Pneedchange12)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                {
                                                    if (maze[PinkyY + 1, PinkyX] == 1)
                                                        Pneedchange12 = 1;
                                                    else
                                                        PinkyY++;
                                                }
                                                else
                                                    PinkyX--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                    PinkyY--;
                                                else
                                                {
                                                    PinkyX--;
                                                    Pneedchange12 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                            }
                            if (PinkyX < px)
                            {
                                if (PinkyY > py + 2)
                                {
                                    switch (Pneedchange13)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY - 1, PinkyX] == 1)
                                                {
                                                    if (maze[PinkyY, PinkyX + 1] == 1)
                                                        Pneedchange13 = 1;
                                                    else
                                                        PinkyX++;
                                                }
                                                else
                                                    PinkyY--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY - 1, PinkyX] == 1)
                                                    PinkyX--;
                                                else
                                                {
                                                    PinkyY--;
                                                    Pneedchange13 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                                if (PinkyY < py + 2)
                                {
                                    switch (Pneedchange14)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX + 1] == 1)
                                                {
                                                    if (maze[PinkyY + 1, PinkyX] == 1)
                                                        Pneedchange14 = 1;
                                                    else
                                                        PinkyY++;
                                                }
                                                else
                                                    PinkyX++;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY + 1, PinkyX] == 1)
                                                    PinkyX--;
                                                else
                                                {
                                                    PinkyY++;
                                                    Pneedchange14 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                            }
                            if (PinkyY == py + 2)
                            {
                                if (PinkyX > px + 2)
                                {
                                    if (maze[PinkyY, PinkyX - 1] != 1)
                                        PinkyX--;
                                    else
                                        PDecision = 4;
                                }
                                if (PinkyX < px + 2)
                                {
                                    if (maze[PinkyY, PinkyX + 1] != 1)
                                        PinkyX++;
                                    else
                                        PDecision = 2;
                                }
                            }
                        }
                    }
                    if (direct == 42)
                    {
                        if (PinkyX == px-2)
                        {
                            if (PinkyY > py)
                            {
                                if (maze[PinkyY - 1, PinkyX] != 1)
                                    PinkyY--;
                                else
                                    PDecision = 1;
                            }
                            if (PinkyY < py)
                            {
                                if (maze[PinkyY + 1, PinkyX] != 1)
                                    PinkyY++;
                                else
                                    PDecision = 3;
                            }
                        }
                        else
                        {
                            if (PinkyX > px-2)
                            {
                                if (PinkyY > py)
                                {
                                    switch (Pneedchange11)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                {
                                                    if (maze[PinkyY - 1, PinkyX] == 1)
                                                        Pneedchange11 = 1;
                                                    else
                                                        PinkyY--;
                                                }
                                                else
                                                    PinkyX--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                    PinkyY++;
                                                else
                                                {
                                                    PinkyX--;
                                                    Pneedchange11 = 0;
                                                }
                                            }
                                            break;
                                    }
                                }
                                if (PinkyY < py)
                                {
                                    switch (Pneedchange12)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                {
                                                    if (maze[PinkyY + 1, PinkyX] == 1)
                                                        Pneedchange12 = 1;
                                                    else
                                                        PinkyY++;
                                                }
                                                else
                                                    PinkyX--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY, PinkyX - 1] == 1)
                                                    PinkyY--;
                                                else
                                                {
                                                    PinkyX--;
                                                    Pneedchange12 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                            }
                            if (PinkyX < px)
                            {
                                if (PinkyY > py)
                                {
                                    switch (Pneedchange13)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY - 1, PinkyX] == 1)
                                                {
                                                    if (maze[PinkyY, PinkyX + 1] == 1)
                                                        Pneedchange13 = 1;
                                                    else
                                                        PinkyX++;
                                                }
                                                else
                                                    PinkyY--;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY - 1, PinkyX] == 1)
                                                    PinkyX--;
                                                else
                                                {
                                                    PinkyY--;
                                                    Pneedchange13 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                                if (PinkyY < py)
                                {
                                    switch (Pneedchange14)
                                    {
                                        case 0:
                                            {
                                                if (maze[PinkyY, PinkyX + 1] == 1)
                                                {
                                                    if (maze[PinkyY + 1, PinkyX] == 1)
                                                        Pneedchange14 = 1;
                                                    else
                                                        PinkyY++;
                                                }
                                                else
                                                    PinkyX++;
                                                break;
                                            }
                                        case 1:
                                            {
                                                if (maze[PinkyY + 1, PinkyX] == 1)
                                                    PinkyX--;
                                                else
                                                {
                                                    PinkyY++;
                                                    Pneedchange14 = 0;
                                                }
                                                break;
                                            }
                                    }
                                }
                            }
                            if (PinkyY == py)
                            {
                                if (PinkyX > px - 2)
                                {
                                    if (maze[PinkyY, PinkyX - 1] != 1)
                                        PinkyX--;
                                    else
                                        PDecision = 4;
                                }
                                if (PinkyX < px - 2)
                                {
                                    if (maze[PinkyY, PinkyX + 1] != 1)
                                        PinkyX++;
                                    else
                                        PDecision = 2;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                switch (PDecision)
                {
                    case 1:
                        {
                            if (maze[PinkyY - 1, PinkyX] == 1)
                            {
                                if (maze[PinkyY, PinkyX -1] != 1)
                                    PinkyX--;
                                else
                                    PDecision = 5;
                            }
                            else
                            {
                                PinkyY--;
                                PDecision = 0;
                            }
                            break;
                        }
                    case 2:
                        {
                            if (maze[PinkyY,PinkyX+1]==1)
                            {
                                if (maze[PinkyY - 1, PinkyX] != 1)
                                    PinkyY--;
                                else
                                    PDecision = 6;
                            }
                            else
                            {
                                PinkyX++;
                                PDecision = 0;
                            }
                            break;
                        }
                    case 3:
                        {
                            if(maze[PinkyY+1,PinkyX]==1)
                            {
                                if (maze[PinkyY, PinkyX - 1] != 1)
                                    PinkyX--;
                                else
                                    PDecision = 7;
                            }
                            else
                            {
                                PinkyY++;
                                PDecision = 0;
                            }
                            break;
                        }
                    case 4:
                        {
                            if(maze[PinkyY,PinkyX-1]==1)
                            {
                                if (maze[PinkyY - 1, PinkyX] != 1)
                                    PinkyY--;
                                else
                                    PDecision = 8;
                            }
                            else
                            {
                                PinkyX--;
                                PDecision = 0;
                            }
                            break;
                        }
                    case 5:
                        {
                            if (maze[PinkyY, PinkyX + 1] != 1&&maze[PinkyY-1,PinkyX]==1)
                                PinkyX++;
                            else
                            {
                                PinkyY--;
                                PDecision = 0;
                            }
                            break;
                        }
                    case 6:
                        {
                            if (maze[PinkyY + 1, PinkyX] != 1 && maze[PinkyY, PinkyX + 1] == 1)
                                PinkyY++;
                            else
                            {
                                PinkyX++;
                                PDecision = 0;
                            }
                            break;
                        }
                    case 7:
                        {
                            if (maze[PinkyY, PinkyX + 1] != 1 && maze[PinkyY + 1, PinkyX] == 1)
                                PinkyX++;
                            else
                            {
                                PinkyY++;
                                PDecision = 0;
                            }
                            break;
                        }
                    case 8:
                        {
                            if (maze[PinkyY + 1, PinkyX] != 1 && maze[PinkyY, PinkyX - 1] == 1)
                                PinkyY++;
                            else
                            {
                                PinkyX--;
                                PDecision=0;
                            }
                            break;
                        }
                }
            }
            pictureBox4.Left = PinkyX * dx;
            pictureBox4.Top = PinkyY * dy;

            if (maze[PinkyY, PinkyX] == 3)
            {
                PinkyX = PinkyX - 25;
            }
            if (maze[PinkyY, PinkyX] == 4)
            {
                PinkyX = PinkyX + 25;
            }
            if (PinkyX == px && PinkyY == py)
            {
                px = 13; py = 23; BlinkyX = 14; BlinkyY = 11;PinkyX = 14;PinkyY = 14;
                pictureBox2.Left = px * dx;
                pictureBox2.Top = py * dy;
                pictureBox3.Left = BlinkyX * dx;
                pictureBox3.Top = BlinkyY * dy;
                pictureBox4.Left = PinkyX * dx;
                pictureBox4.Top = PinkyY * dy;

                pictureBox2.Visible = true;
                pictureBox3.Visible = true;
                pictureBox4.Visible = true;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                PinkyOut.Enabled = false;
                Out = 0;
                Life--;
                if (Life == 2)
                {
                    pictureBox7.Visible = false;
                    Starter.Enabled = true;
                }
                if (Life == 1)
                {
                    pictureBox8.Visible = false;
                    Starter.Enabled = true;
                }
                if (Life == 0)
                {
                    pictureBox9.Visible = true;
                    pictureBox1.Visible = false;
                    button3.Enabled = true;
                    timer1.Enabled = false;
                    timer2.Enabled = false;
                    timer3.Enabled = false;
                    timer4.Enabled = false;
                    axWindowsMediaPlayer1.Ctlcontrols.stop();
                    axWindowsMediaPlayer2.Ctlcontrols.play();
                    Reset.Enabled = true;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int y = 0; y < 31; y++)
            {
                for (int x = 0; x < 28; x++)
                {
                    if (maze[y, x] == 0)
                        g.DrawImage(bean, x * dx, y * dy);
                    else
                        g.DrawImage(wall, x * dx, y * dy);
                    if (maze[y, x] == 2)
                        g.DrawImage(street, x * dx, y * dy);
                }
            }
            pictureBox1.Image = bmp;
            pictureBox1.Controls.Add(pictureBox2);
            pictureBox1.Controls.Add(pictureBox3);
            pictureBox1.Controls.Add(pictureBox4);
            pictureBox2.BackColor = Color.Transparent;
            pictureBox3.BackColor = Color.Transparent;
            pictureBox4.BackColor = Color.Transparent;
            pictureBox10.BackColor = Color.Transparent;

            pictureBox2.Image = Image.FromFile("PacMan42.png");
            pictureBox3.Image = Blinky;
            pictureBox4.Image = Pinky;
            px = 13; py = 23;BlinkyX = 13;BlinkyY = 11;PinkyX = 13;PinkyY=14;
            pictureBox2.Left = px * dx;
            pictureBox2.Top = py * dy;
            pictureBox3.Left = BlinkyX * dx;
            pictureBox3.Top = BlinkyY * dy;
            pictureBox4.Left = PinkyX * dx;
            pictureBox4.Top = PinkyY * dy;

            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            pictureBox6.Visible = true;
            pictureBox7.Visible = true;
            pictureBox8.Visible = true;
            pictureBox10.Visible = true;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            button3.Visible = false;

            Life = 3;

            label1.Visible = true;
            label2.Visible = true;
            Starter.Enabled = true;
            button3.Enabled = false;
            axWindowsMediaPlayer1.Ctlcontrols.play();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (direct)
            {
                case 12:
                    {
                        if (maze[py - 1, px] == 1)
                        {
                            return;
                        }
                        py--;
                        break;
                    }
                case 22:
                    {
                        if (maze[py, px + 1] == 1)
                        {
                            return;
                        }
                        px++;
                        break;
                    }
                case 32:
                    {
                        if (maze[py + 1, px] == 1)
                        {
                            return;
                        }
                        py++;
                        break;
                    }
                case 42:
                    {
                        if (maze[py, px - 1] == 1)
                        {
                            return;
                        }
                        px--;
                        break;
                    }
            }
            if (maze[py, px] == 3&&direct==22)
                px = px - 26;
            if (maze[py,px]==4&&direct==42)
                px = px + 26;
            pictureBox2.Left = px * dx;
            pictureBox2.Top = py * dy;
            
            if (maze[py,px]==0)
            {
                maze[py, px] = 5;
                g.DrawImage(streetB, px * dx, py * dy);
                BeanCount--;
                Point = Point + 10;
            }
            if(BeanCount<=40)
            {
                timer3.Interval = 140;
                timer4.Interval = 140;
            }
            if(BeanCount==0)
            {
                pictureBox9.Visible = true;
                pictureBox1.Visible = true;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                pictureBox4.Visible = false;
                pictureBox5.Visible = true;
                pictureBox6.Visible = true;
                pictureBox7.Visible = false;
                pictureBox8.Visible = false;
                pictureBox10.Visible = false;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                Wintimer.Enabled = true;
            }
            if (BlinkyX == px && BlinkyY == py && Life != 0)
            {
                px = 13; py = 23; BlinkyX = 14; BlinkyY = 11; PinkyX = 14; PinkyY = 14;
                pictureBox2.Left = px * dx;
                pictureBox2.Top = py * dy;
                pictureBox3.Left = BlinkyX * dx;
                pictureBox3.Top = BlinkyY * dy;
                pictureBox4.Left = PinkyX * dx;
                pictureBox4.Top = PinkyY * dy;

                pictureBox2.Visible = true;
                pictureBox3.Visible = true;
                pictureBox4.Visible = true;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                PinkyOut.Enabled = false;
                Out = 0;
                Life--;
                if (Life == 2)
                {
                    pictureBox7.Visible = false;
                    Starter.Enabled = true;
                }
                if (Life == 1)
                {
                    pictureBox8.Visible = false;
                    Starter.Enabled = true;
                }
                if (Life == 0)
                {
                    pictureBox9.Visible = true;
                    pictureBox1.Visible = false;
                    button1.Enabled = true;
                    timer1.Enabled = false;
                    timer2.Enabled = false;
                    timer3.Enabled = false;
                    timer4.Enabled = false;
                    axWindowsMediaPlayer1.Ctlcontrols.stop();
                    axWindowsMediaPlayer2.Ctlcontrols.play();
                    Reset.Enabled = true;
                }
            }
            if (PinkyX == px && PinkyY == py && Life != 0)
            {
                px = 13; py = 23; BlinkyX = 14; BlinkyY = 11; PinkyX = 14; PinkyY = 14;
                pictureBox2.Left = px * dx;
                pictureBox2.Top = py * dy;
                pictureBox3.Left = BlinkyX * dx;
                pictureBox3.Top = BlinkyY * dy;
                pictureBox4.Left = PinkyX * dx;
                pictureBox4.Top = PinkyY * dy;

                pictureBox2.Visible = true;
                pictureBox3.Visible = true;
                pictureBox4.Visible = true;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                PinkyOut.Enabled = false;
                Out = 0;
                Life--;
                if (Life == 2)
                {
                    pictureBox7.Visible = false;
                    Starter.Enabled = true;
                }
                if (Life == 1)
                {
                    pictureBox8.Visible = false;
                    Starter.Enabled = true;
                }
                if (Life == 0)
                {
                    pictureBox9.Visible = true;
                    pictureBox1.Visible = false;
                    button1.Enabled = true;
                    timer1.Enabled = false;
                    timer2.Enabled = false;
                    timer3.Enabled = false;
                    timer4.Enabled = false;
                    axWindowsMediaPlayer1.Ctlcontrols.stop();
                    axWindowsMediaPlayer2.Ctlcontrols.play();
                    Reset.Enabled = true;
                }
            }
            label1.Text = Point.ToString();
            if (Point > HighScore)
                HighScore = Point;
                label2.Text = HighScore.ToString();
            pictureBox1.Image = bmp;
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (BDecision == 0)
            {
                if (BlinkyX == px)
                {
                    needchange1 = 0; needchange2 = 0; needchange3 = 0; needchange4 = 0;
                    if (BlinkyY > py)
                    {
                        if (maze[BlinkyY - 1, BlinkyX] != 1)
                            BlinkyY--;
                        else
                        BDecision = 1;
                    }
                    if (BlinkyY < py)
                    {
                        if (maze[BlinkyY + 1, BlinkyX] != 1)
                            BlinkyY++;
                        else
                        BDecision = 3;
                    }
                }
                else
                {
                    if (BlinkyX > px)
                    {
                        if (BlinkyY < py)
                        {
                            switch (needchange2)
                            {
                                case 0:
                                    {
                                        if (maze[BlinkyY + 1, BlinkyX] == 1)
                                        {
                                            if (maze[BlinkyY, BlinkyX - 1] == 1)
                                                needchange2 = 1;
                                            else
                                                BlinkyX--;
                                        }
                                        else
                                            BlinkyY++;
                                        break;
                                    }
                                case 1:
                                    {
                                        if (maze[BlinkyY + 1, BlinkyX] == 1)
                                            BlinkyX++;
                                        else
                                        {
                                            BlinkyY++;
                                            needchange2 = 0;
                                        }
                                        break;
                                    }
                            }
                        }
                    }
                    if (BlinkyX < px)
                    {
                        if (BlinkyY > py)
                        {
                            switch (needchange4)
                            {
                                case 0:
                                    {
                                        if (maze[BlinkyY, BlinkyX + 1] == 1)
                                        {
                                            if (maze[BlinkyY - 1, BlinkyX] == 1)
                                                needchange4 = 1;
                                            else
                                                BlinkyY--;
                                        }
                                        else
                                            BlinkyX++;
                                        break;
                                    }
                                case 1:
                                    {
                                        if (maze[BlinkyY - 1, BlinkyX] == 1)
                                            BlinkyX--;
                                        else
                                        {
                                            BlinkyY--;
                                            needchange4 = 0;
                                        }
                                        break;
                                    }
                            }
                        }
                    }
                    if (BlinkyY == py)
                    {
                        needchange1 = 0; needchange2 = 0; needchange3 = 0; needchange4 = 0;
                        if (BlinkyX > px)
                        {
                            if (maze[BlinkyY, BlinkyX - 1] != 1)
                                BlinkyX--;
                            else
                            BDecision = 4;
                        }
                        if (BlinkyX < px)
                        {
                            if (maze[BlinkyY, BlinkyX + 1] != 1)
                                BlinkyX++;
                            else
                            BDecision = 2;
                        }
                    }
                    else
                    {
                        if (BlinkyX < px)
                        {
                            if (BlinkyY < py)
                            {
                                switch (needchange3)
                                {
                                    case 0:
                                        {
                                            if (maze[BlinkyY + 1, BlinkyX] == 1)
                                            {
                                                if (maze[BlinkyY, BlinkyX + 1] == 1)
                                                    needchange3 = 1;
                                                else
                                                    BlinkyX++;
                                            }
                                            else
                                                BlinkyY++;
                                            break;
                                        }
                                    case 1:
                                        {
                                            if (maze[BlinkyY+1, BlinkyX] == 1)
                                                BlinkyX--;
                                            else
                                            {
                                                BlinkyY++;
                                                needchange3 = 0;
                                            }
                                            break;
                                        }
                                }
                            }
                        }
                        if (BlinkyX > px)
                        {
                            if (BlinkyY > py)
                            {
                                switch (needchange1)
                                {
                                    case 0:
                                        {
                                            if (maze[BlinkyY - 1, BlinkyX] == 1)
                                            {
                                                if (maze[BlinkyY, BlinkyX - 1] == 1)
                                                    needchange1 = 1;
                                                else
                                                    BlinkyX--;
                                            }
                                            else
                                                BlinkyY--;
                                            break;
                                        }
                                    case 1:
                                        {
                                            if (maze[BlinkyY - 1, BlinkyX] == 1)
                                                BlinkyX++;
                                            else
                                            {
                                                BlinkyY--;
                                                needchange1 = 0;
                                            }
                                            break;
                                        }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                switch (BDecision)
                {
                    case 1:
                        {
                            if (maze[BlinkyY - 1, BlinkyX] == 1)
                            {
                                if (maze[BlinkyY, BlinkyX + 1] != 1)
                                    BlinkyX++;
                                else
                                    BDecision = 5;
                            }
                            else
                            {
                                BlinkyY--;
                                BDecision = 0;
                            }
                            break;
                        }
                    case 2:
                        {
                            if (maze[BlinkyY, BlinkyX+1] == 1)
                            {
                                if (maze[BlinkyY + 1, BlinkyX] != 1)
                                    BlinkyY++;
                                else
                                    BDecision = 6;
                            }
                            else
                            {
                                BlinkyX++;
                                BDecision = 0;
                            }
                            break;
                        }
                    case 3:
                        {
                            if (maze[BlinkyY+1, BlinkyX] == 1)
                            {
                                if (maze[BlinkyY, BlinkyX + 1] != 1)
                                    BlinkyX++;
                                else
                                    BDecision = 7;
                            }
                            else
                            {
                                BlinkyY++;
                                BDecision = 0;
                            }
                            break;
                        }
                    case 4:
                        {
                            if (maze[BlinkyY,BlinkyX-1]==1)
                            {
                                if (maze[BlinkyY - 1, BlinkyX] != 1)
                                    BlinkyY--;
                                else
                                    BDecision = 8;
                            }
                            else
                            {
                                BlinkyX--;
                                BDecision = 0;
                            }
                            break;
                        }
                    case 5:
                        {
                            if (maze[BlinkyY, BlinkyX-1] != 1&&maze[BlinkyY-1,BlinkyX]==1)
                                BlinkyX--;
                            else
                            {
                                BlinkyY--;
                                BDecision = 0;
                            }
                            break;
                        }
                    case 6:
                        {
                            if (maze[BlinkyY-1, BlinkyX] != 1&&maze[BlinkyY,BlinkyX+1]==1)
                                BlinkyY--;
                            else
                            {
                                BlinkyX++;
                                BDecision = 0;
                            }
                            break;
                        }
                    case 7:
                        {
                            if (maze[BlinkyY, BlinkyX - 1] != 1 && maze[BlinkyY+1,BlinkyX]==1)
                                BlinkyX++;
                            else
                            {
                                BlinkyY++;
                                BDecision = 0;
                            }
                            break;
                        }
                    case 8:
                        {
                            if(maze[BlinkyY+1,BlinkyX]!=1&&maze[BlinkyY,BlinkyX-1]==1)
                            {
                                BlinkyY++;
                            }
                            else
                            {
                                BlinkyX--;
                                BDecision = 0;
                            }
                            break;
                        }
                }
            }
            if(maze[BlinkyY,BlinkyX]==3)
            {
                BlinkyX = BlinkyX - 25;
            }
            if(maze[BlinkyY,BlinkyX]==4)
            {
                BlinkyX = BlinkyX + 25;
            }
            if (BlinkyX==px&&BlinkyY==py)
            {
                px = 13; py = 23; BlinkyX = 14; BlinkyY = 11;PinkyX = 14;PinkyY = 14;
                pictureBox2.Left = px * dx;
                pictureBox2.Top = py * dy;
                pictureBox3.Left = BlinkyX * dx;
                pictureBox3.Top = BlinkyY * dy;
                pictureBox4.Left = PinkyX * dx;
                pictureBox4.Top = PinkyY * dy;

                pictureBox2.Visible = true;
                pictureBox3.Visible = true;
                pictureBox4.Visible = true;
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                timer4.Enabled = false;
                PinkyOut.Enabled = false;
                Out = 0;
                Life--;
                if (Life == 2)
                {
                    pictureBox7.Visible = false;
                    Starter.Enabled = true;
                }
                if (Life == 1)
                {
                    pictureBox8.Visible = false;
                    Starter.Enabled = true;
                }
                if (Life == 0)
                {
                    pictureBox9.Visible = true;
                    timer1.Enabled = false;
                    timer2.Enabled = false;
                    timer3.Enabled = false;
                    timer4.Enabled = false;
                    pictureBox1.Visible = false;
                    axWindowsMediaPlayer1.Ctlcontrols.stop();
                    axWindowsMediaPlayer2.Ctlcontrols.play();
                    Reset.Enabled = true;
                }
            }
            pictureBox3.Left = BlinkyX * dx;
            pictureBox3.Top = BlinkyY * dy;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (direct)
            {
                case 12:
                    {
                        if (changeP == 2)
                        {
                            changeP = 5;
                        }
                        changeP--;
                        pictureBox2.Image = Image.FromFile("Pacman1" + changeP.ToString() + ".png");
                        break;
                    }
                case 22:
                    {
                        if (changeP == 2)
                        {
                            changeP = 5;
                        }
                        changeP--;
                        pictureBox2.Image = Image.FromFile("Pacman2" + changeP.ToString() + ".png");
                        break;
                    }
                case 32:
                    {
                        if(changeP == 2)
                        {
                            changeP = 5;
                        }
                        changeP--;
                        pictureBox2.Image = Image.FromFile("Pacman3" + changeP.ToString() + ".png");
                        break;
                    }
                case 42:
                    {
                        if (changeP == 2)
                        {
                            changeP = 5;
                        }
                        changeP--;
                        pictureBox2.Image = Image.FromFile("Pacman4" + changeP.ToString() + ".png");
                        break;
                    }
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    if (maze[py - 1, px] == 1)
                        return;
                    new_direct = 12;

                    break;
                case Keys.Down:
                    if (maze[py + 1, px] == 1)
                        return;
                    new_direct = 32;
                    break;
                case Keys.Left:
                    if (maze[py, px - 1] == 1)
                        return;
                    new_direct = 42;
                    break;
                case Keys.Right:
                    if (maze[py, px + 1] == 1)
                        return;
                    new_direct = 22;
                    break;
            }
            if (direct != new_direct)
            {
                direct = new_direct;
                pictureBox2.Image = Image.FromFile("PacMan" + direct.ToString() + ".png");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            street = Image.FromFile("Street.png");
            wall = Image.FromFile("wall.png");
            bean = Image.FromFile("bean.png");
            streetB = Image.FromFile("StreetB.png");
            Blinky = Image.FromFile("Blinky1.png");
            Pinky = Image.FromFile("Pinky1.png");
            
            axWindowsMediaPlayer1.settings.autoStart = false;
            axWindowsMediaPlayer1.URL=("PacManTheme.mp3");
            axWindowsMediaPlayer2.settings.autoStart = false;
            axWindowsMediaPlayer2.URL = ("Dying.mp3");

            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            g = Graphics.FromImage(bmp);
            pictureBox2.Image=street;
        }
    }
}
